﻿using System;
namespace TwitterMvc.Dtos
{
    public class ProfileDtos
    {
        public string Username { get; set; }
    }
}
